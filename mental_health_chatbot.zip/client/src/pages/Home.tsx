import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { Heart, MessageCircle, TrendingUp, BookOpen, Sparkles, ArrowRight } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border/40 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary" fill="currentColor" />
            <span className="text-xl font-semibold text-foreground">MindCare</span>
          </div>
          <a href={getLoginUrl()}>
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Sign In
            </Button>
          </a>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-20 sm:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl sm:text-6xl font-bold text-foreground leading-tight">
                Your Personal Mental Health
                <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent"> Companion</span>
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Connect with an empathetic AI chatbot, track your emotional well-being, and access curated mental health resources—all in one beautiful, supportive space.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href={getLoginUrl()}>
                <Button size="lg" className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground">
                  Get Started <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
              <Button size="lg" variant="outline" className="w-full sm:w-auto">
                Learn More
              </Button>
            </div>
          </div>

          {/* Illustration */}
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-3xl blur-3xl" />
            <div className="relative bg-card rounded-3xl p-8 border border-border shadow-lg">
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                    <MessageCircle className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 space-y-2">
                    <div className="h-2 bg-muted rounded w-24" />
                    <div className="h-2 bg-muted rounded w-32" />
                  </div>
                </div>
                <div className="flex gap-3 justify-end">
                  <div className="flex-1 space-y-2">
                    <div className="h-2 bg-primary rounded w-24 ml-auto" />
                    <div className="h-2 bg-primary rounded w-32 ml-auto" />
                  </div>
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                    <span className="text-xs text-primary-foreground">You</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Designed for Your Wellness</h2>
          <p className="text-lg text-muted-foreground">Everything you need to support your mental health journey</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              icon: MessageCircle,
              title: "AI Chatbot",
              description: "Empathetic conversations with an AI trained to listen and support",
            },
            {
              icon: TrendingUp,
              title: "Mood Tracking",
              description: "Log your emotions and visualize patterns over time",
            },
            {
              icon: BookOpen,
              title: "Resources",
              description: "Access articles, coping strategies, and crisis support",
            },
            {
              icon: Heart,
              title: "Personalized",
              description: "Your data is private and your experience is tailored to you",
            },
          ].map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div key={i} className="bg-card rounded-2xl p-6 border border-border hover:shadow-lg transition-all duration-300">
                <Icon className="w-8 h-8 text-primary mb-4" />
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-20">
        <div className="bg-gradient-to-r from-primary to-secondary rounded-3xl p-12 text-center">
          <Sparkles className="w-12 h-12 text-primary-foreground mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">Ready to Start Your Journey?</h2>
          <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Join thousands of people who are taking control of their mental health with MindCare.
          </p>
          <a href={getLoginUrl()}>
            <Button size="lg" className="bg-primary-foreground hover:bg-primary-foreground/90 text-primary">
              Sign In Now <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 mt-20">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2024 MindCare. Your mental health matters. Always seek professional help if needed.</p>
        </div>
      </footer>
    </div>
  );
}
