import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Loader2, TrendingUp } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const MOOD_OPTIONS = [
  { level: 1, label: "Very Sad", emoji: "😢", color: "text-red-500" },
  { level: 2, label: "Anxious", emoji: "😰", color: "text-amber-500" },
  { level: 3, label: "Neutral", emoji: "😐", color: "text-gray-500" },
  { level: 4, label: "Calm", emoji: "😌", color: "text-green-500" },
  { level: 5, label: "Happy", emoji: "😊", color: "text-blue-500" },
];

export default function MoodTracker() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: moodHistory, refetch: refetchHistory } = trpc.mood.getHistory.useQuery();
  const { data: moodStats } = trpc.mood.getStats.useQuery();
  const logMoodMutation = trpc.mood.logMood.useMutation({
    onSuccess: () => {
      setSelectedMood(null);
      setNotes("");
      refetchHistory();
    },
  });

  const handleLogMood = async () => {
    if (!selectedMood) return;

    setIsSubmitting(true);
    try {
      const selectedOption = MOOD_OPTIONS.find(m => m.level === selectedMood);
      await logMoodMutation.mutateAsync({
        moodLevel: selectedMood,
        moodLabel: selectedOption?.label || "Unknown",
        notes: notes || undefined,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Prepare chart data
  const chartData = moodHistory?.map(entry => ({
    date: new Date(entry.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    mood: entry.moodLevel,
    label: entry.moodLabel,
  })) || [];

  const distributionData = moodStats?.moodDistribution
    ? Object.entries(moodStats.moodDistribution).map(([label, count]) => ({
        name: label,
        count,
      }))
    : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Mood Tracker</h1>
        </div>
      </header>

      <div className="container py-8">
        {/* Log Mood Section */}
        <div className="bg-card rounded-2xl p-8 border border-border mb-8">
          <h2 className="text-2xl font-semibold text-foreground mb-6">How are you feeling today?</h2>

          {/* Mood Selection */}
          <div className="grid grid-cols-5 gap-4 mb-8">
            {MOOD_OPTIONS.map((mood) => (
              <button
                key={mood.level}
                onClick={() => setSelectedMood(mood.level)}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl transition-all duration-200 ${
                  selectedMood === mood.level
                    ? "bg-primary/20 border-2 border-primary scale-105"
                    : "bg-muted/20 border-2 border-transparent hover:bg-muted/40"
                }`}
              >
                <span className="text-3xl">{mood.emoji}</span>
                <span className="text-xs font-medium text-foreground text-center">{mood.label}</span>
              </button>
            ))}
          </div>

          {/* Notes */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-foreground mb-2">
              Add notes (optional)
            </label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="What's on your mind? Any specific triggers or thoughts?"
              className="min-h-24 rounded-lg border-border bg-background focus:ring-2 focus:ring-primary focus:ring-opacity-20"
            />
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleLogMood}
            disabled={!selectedMood || isSubmitting}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            size="lg"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Logging...
              </>
            ) : (
              "Log Mood"
            )}
          </Button>
        </div>

        {/* Stats Section */}
        {moodStats && (
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="bg-card rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Average Mood
              </h3>
              <div className="text-4xl font-bold text-primary mb-2">{moodStats.averageMood}</div>
              <p className="text-sm text-muted-foreground">out of 5 in the last 30 days</p>
            </div>

            <div className="bg-card rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Entries Logged</h3>
              <div className="text-4xl font-bold text-secondary mb-2">{moodStats.totalEntries}</div>
              <p className="text-sm text-muted-foreground">mood entries tracked</p>
            </div>
          </div>
        )}

        {/* Charts Section */}
        {chartData.length > 0 && (
          <div className="space-y-8">
            {/* Line Chart */}
            <div className="bg-card rounded-2xl p-6 border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Mood Trend</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" stroke="var(--muted-foreground)" />
                  <YAxis domain={[1, 5]} stroke="var(--muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "var(--card)",
                      border: "1px solid var(--border)",
                      borderRadius: "8px",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="mood"
                    stroke="var(--primary)"
                    strokeWidth={2}
                    dot={{ fill: "var(--primary)", r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Distribution Chart */}
            {distributionData.length > 0 && (
              <div className="bg-card rounded-2xl p-6 border border-border">
                <h3 className="text-lg font-semibold text-foreground mb-4">Mood Distribution</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={distributionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                    <YAxis stroke="var(--muted-foreground)" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="count" fill="var(--secondary)" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {chartData.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Start logging your moods to see your trends here</p>
          </div>
        )}
      </div>
    </div>
  );
}
