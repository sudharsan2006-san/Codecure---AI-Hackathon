import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowLeft, BookOpen, Lightbulb, AlertCircle, Zap, Dumbbell, ExternalLink, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";

const CATEGORY_INFO = {
  article: { icon: BookOpen, color: "text-blue-500", bg: "bg-blue-50 dark:bg-blue-900/20" },
  coping_strategy: { icon: Lightbulb, color: "text-amber-500", bg: "bg-amber-50 dark:bg-amber-900/20" },
  crisis_hotline: { icon: AlertCircle, color: "text-red-500", bg: "bg-red-50 dark:bg-red-900/20" },
  meditation: { icon: Zap, color: "text-purple-500", bg: "bg-purple-50 dark:bg-purple-900/20" },
  exercise: { icon: Dumbbell, color: "text-green-500", bg: "bg-green-50 dark:bg-green-900/20" },
};

export default function Resources() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const { data: allResources, isLoading } = trpc.resources.getAll.useQuery();

  const filteredResources = selectedCategory
    ? allResources?.filter(r => r.category === selectedCategory)
    : allResources;

  const categories = [
    { value: null, label: "All Resources" },
    { value: "article", label: "Articles" },
    { value: "coping_strategy", label: "Coping Strategies" },
    { value: "crisis_hotline", label: "Crisis Support" },
    { value: "meditation", label: "Meditation" },
    { value: "exercise", label: "Exercise" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center gap-4 h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl font-semibold text-foreground">Mental Health Resources</h1>
        </div>
      </header>

      <div className="container py-8">
        {/* Category Filter */}
        <div className="mb-8">
          <h2 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wide">Filter by Category</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((cat) => (
              <button
                key={cat.value || "all"}
                onClick={() => setSelectedCategory(cat.value as any)}
                className={`px-4 py-2 rounded-full font-medium transition-all duration-200 ${
                  selectedCategory === cat.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border text-foreground hover:border-primary"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Resources Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredResources && filteredResources.length > 0 ? (
          <div className="space-y-4">
            {filteredResources.map((resource) => {
              const categoryInfo = CATEGORY_INFO[resource.category as keyof typeof CATEGORY_INFO];
              const Icon = categoryInfo?.icon || BookOpen;
              const isExpanded = expandedId === resource.id;

              return (
                <div
                  key={resource.id}
                  className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-md transition-all duration-300"
                >
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : resource.id)}
                    className="w-full p-6 text-left hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-lg ${categoryInfo?.bg}`}>
                        <Icon className={`w-6 h-6 ${categoryInfo?.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-1">{resource.title}</h3>
                            <p className="text-sm text-muted-foreground">{resource.description}</p>
                            {resource.author && (
                              <p className="text-xs text-muted-foreground mt-2">By {resource.author}</p>
                            )}
                          </div>
                          <span className="text-xs font-medium text-muted-foreground bg-muted/50 px-2 py-1 rounded">
                            {resource.category.replace(/_/g, " ")}
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>

                  {/* Expanded Content */}
                  {isExpanded && (
                    <div className="border-t border-border px-6 py-4 bg-muted/20 animate-fade-in">
                      <div className="prose prose-sm dark:prose-invert max-w-none mb-4">
                        <Streamdown>{resource.content}</Streamdown>
                      </div>
                      {resource.link && (
                        <a
                          href={resource.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-primary hover:text-primary/80 font-medium"
                        >
                          Learn More <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No resources found in this category</p>
          </div>
        )}
      </div>
    </div>
  );
}
