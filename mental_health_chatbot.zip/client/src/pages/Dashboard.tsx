import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, TrendingUp, BookOpen, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const { data: latestMood, isLoading: moodLoading } = trpc.mood.getLatest.useQuery();
  const { data: moodStats } = trpc.mood.getStats.useQuery();

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 z-50 bg-card/95 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-primary" fill="currentColor" />
            <span className="text-xl font-semibold text-foreground">MindCare</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Welcome, {user?.name || "Friend"}</span>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground hover:text-foreground">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container py-8">
        {/* Welcome Section */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">Welcome back, {user?.name?.split(" ")[0]}</h1>
          <p className="text-muted-foreground">How are you feeling today?</p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <MessageCircle className="w-6 h-6 text-primary" />
              <span className="text-xs font-medium text-muted-foreground">Chat</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">Talk</h3>
            <p className="text-sm text-muted-foreground mt-2">Start a conversation with your AI companion</p>
          </div>

          <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-6 h-6 text-secondary" />
              <span className="text-xs font-medium text-muted-foreground">Mood</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">
              {moodLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : latestMood?.moodLabel || "Log Mood"}
            </h3>
            <p className="text-sm text-muted-foreground mt-2">Track your emotional journey</p>
          </div>

          <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <BookOpen className="w-6 h-6 text-accent" />
              <span className="text-xs font-medium text-muted-foreground">Resources</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">Learn</h3>
            <p className="text-sm text-muted-foreground mt-2">Explore helpful articles and strategies</p>
          </div>

          <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-md transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <Heart className="w-6 h-6 text-primary" />
              <span className="text-xs font-medium text-muted-foreground">Wellness</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">
              {moodStats?.totalEntries || 0}
            </h3>
            <p className="text-sm text-muted-foreground mt-2">Mood entries logged</p>
          </div>
        </div>

        {/* Navigation Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          <button
            onClick={() => navigate("/chat")}
            className="group bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl p-8 border border-primary/20 hover:border-primary/40 hover:shadow-lg transition-all duration-300"
          >
            <MessageCircle className="w-12 h-12 text-primary mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-semibold text-foreground mb-2">Start Chatting</h3>
            <p className="text-muted-foreground">Have a supportive conversation with your AI companion</p>
          </button>

          <button
            onClick={() => navigate("/mood")}
            className="group bg-gradient-to-br from-secondary/10 to-secondary/5 rounded-2xl p-8 border border-secondary/20 hover:border-secondary/40 hover:shadow-lg transition-all duration-300"
          >
            <TrendingUp className="w-12 h-12 text-secondary mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-semibold text-foreground mb-2">Track Mood</h3>
            <p className="text-muted-foreground">Log your emotional state and visualize patterns</p>
          </button>

          <button
            onClick={() => navigate("/resources")}
            className="group bg-gradient-to-br from-accent/10 to-accent/5 rounded-2xl p-8 border border-accent/20 hover:border-accent/40 hover:shadow-lg transition-all duration-300"
          >
            <BookOpen className="w-12 h-12 text-accent mb-4 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-semibold text-foreground mb-2">Resources</h3>
            <p className="text-muted-foreground">Access articles, strategies, and support</p>
          </button>
        </div>
      </div>
    </div>
  );
}
