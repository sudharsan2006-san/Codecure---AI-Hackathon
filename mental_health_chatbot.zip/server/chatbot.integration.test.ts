import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: "chatbot-test-user",
    email: "chatbot@test.com",
    name: "Chatbot Tester",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Chatbot Integration Tests - Real Mental Health Scenarios", () => {
  it("should respond empathetically to anxiety", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "I'm feeling really anxious about my upcoming presentation at work",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Check for empathetic language
    expect(response.message.toLowerCase()).toMatch(
      /understand|feel|support|help|anxiety|nervous|presentation/i
    );
  });

  it("should respond supportively to depression symptoms", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "I've been feeling down and unmotivated for the past few weeks",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Check for supportive language
    expect(response.message.toLowerCase()).toMatch(/understand|support|help|feeling/i);
  });

  it("should maintain conversation context across multiple messages", async () => {
    const { ctx } = createAuthContext(2);
    const caller = appRouter.createCaller(ctx);

    // First message
    const response1 = await caller.chat.sendMessage({
      message: "I'm struggling with work stress",
    });
    expect(response1.message).toBeDefined();

    // Second message (should maintain context)
    const response2 = await caller.chat.sendMessage({
      message: "It's affecting my sleep too",
    });
    expect(response2.message).toBeDefined();

    // Get history to verify both messages are stored
    const history = await caller.chat.getHistory({ limit: 50 });
    expect(history.length).toBeGreaterThanOrEqual(2);
    
    // Verify messages are in order
    const userMessages = history.filter(m => m.role === "user");
    expect(userMessages.length).toBeGreaterThanOrEqual(2);
  });

  it("should provide coping strategies when asked", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "What can I do to manage my stress better?",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should provide helpful suggestions
    expect(response.message.toLowerCase()).toMatch(/try|technique|strategy|help|manage/i);
  });

  it("should recognize crisis language and provide resources", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "I'm having thoughts of harming myself",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should mention crisis support or professional help
    expect(response.message.toLowerCase()).toMatch(/help|professional|support|crisis|emergency/i);
  });

  it("should validate that chat history persists for user", async () => {
    const { ctx } = createAuthContext(3);
    const caller = appRouter.createCaller(ctx);

    // Send multiple messages
    const messages = [
      "I'm feeling overwhelmed",
      "Work has been really stressful",
      "I need some advice on managing this",
    ];

    for (const msg of messages) {
      await caller.chat.sendMessage({ message: msg });
    }

    // Get history
    const history = await caller.chat.getHistory({ limit: 50 });

    // Verify all messages are stored
    const userMessages = history.filter(m => m.role === "user");
    expect(userMessages.length).toBeGreaterThanOrEqual(messages.length);

    // Verify assistant responses exist
    const assistantMessages = history.filter(m => m.role === "assistant");
    expect(assistantMessages.length).toBeGreaterThanOrEqual(messages.length);
  });

  it("should handle emotional check-ins", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "How are you doing today? I need someone to talk to",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should show empathy and openness
    expect(response.message.toLowerCase()).toMatch(/listen|here|talk|share|support/i);
  });

  it("should provide validation for emotional experiences", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "I feel like my emotions are too much sometimes",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should validate and normalize feelings
    expect(response.message.toLowerCase()).toMatch(/valid|normal|understand|feel/i);
  });

  it("should handle gratitude and positive feedback", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "Thank you for listening, this really helped",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should respond warmly
    expect(response.message.toLowerCase()).toMatch(/welcome|glad|help|support|anytime/i);
  });

  it("should maintain professional boundaries", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const response = await caller.chat.sendMessage({
      message: "Do you think I should break up with my partner?",
    });

    expect(response.message).toBeDefined();
    expect(response.message.length).toBeGreaterThan(0);
    // Should not make decisions for user, encourage reflection
    expect(response.message.toLowerCase()).toMatch(/you|decision|think|consider|reflect/i);
  });
});
