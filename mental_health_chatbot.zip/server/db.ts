import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, chatMessages, moodEntries, resources } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Chat message queries
export async function saveChatMessage(userId: number, role: "user" | "assistant", content: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(chatMessages).values({
    userId,
    role,
    content,
  });

  return result;
}

export async function getChatHistory(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const messages = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.userId, userId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(limit);

  return messages.reverse(); // Return in chronological order
}

// Mood entry queries
export async function saveMoodEntry(userId: number, moodLevel: number, moodLabel: string, notes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(moodEntries).values({
    userId,
    moodLevel,
    moodLabel,
    notes,
  });

  return result;
}

export async function getMoodHistory(userId: number, days: number = 30) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  const moods = await db
    .select()
    .from(moodEntries)
    .where(
      and(
        eq(moodEntries.userId, userId),
      )
    )
    .orderBy(desc(moodEntries.createdAt));

  return moods;
}

export async function getLatestMoodEntry(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(moodEntries)
    .where(eq(moodEntries.userId, userId))
    .orderBy(desc(moodEntries.createdAt))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

// Resources queries
export async function getAllResources() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const allResources = await db.select().from(resources).orderBy(desc(resources.createdAt));

  return allResources;
}

export async function getResourcesByCategory(category: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(resources)
    .where(eq(resources.category, category as any))
    .orderBy(desc(resources.createdAt));

  return result;
}

export async function seedResources() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if resources already exist
  const existing = await db.select().from(resources).limit(1);
  if (existing.length > 0) {
    console.log("[Database] Resources already seeded");
    return;
  }

  const seedData = [
    {
      title: "Understanding Anxiety",
      category: "article" as const,
      description: "Learn about anxiety disorders and how they affect your daily life.",
      content: "Anxiety is a natural response to stress. However, when anxiety becomes persistent and interferes with daily activities, it may be time to seek professional help. Understanding the symptoms and triggers can help you manage anxiety effectively.",
      author: "Mental Health Expert",
    },
    {
      title: "Deep Breathing Technique",
      category: "coping_strategy" as const,
      description: "A simple technique to calm your nervous system.",
      content: "Try the 4-7-8 breathing technique: Breathe in for 4 counts, hold for 7 counts, exhale for 8 counts. Repeat 4 times. This technique can help reduce anxiety and promote relaxation.",
      author: "Wellness Coach",
    },
    {
      title: "National Suicide Prevention Lifeline",
      category: "crisis_hotline" as const,
      description: "24/7 support for people in crisis.",
      content: "If you are having thoughts of suicide, please reach out. Call 988 (US) or text HOME to 741741. Professional counselors are available 24/7.",
      link: "https://suicidepreventionlifeline.org",
      author: "Crisis Support",
    },
    {
      title: "Guided Meditation for Sleep",
      category: "meditation" as const,
      description: "A 10-minute meditation to help you fall asleep peacefully.",
      content: "Find a comfortable position, close your eyes, and follow along with this guided meditation designed to help you relax and prepare for restful sleep.",
      author: "Meditation Instructor",
    },
    {
      title: "Morning Yoga Routine",
      category: "exercise" as const,
      description: "Start your day with energizing yoga poses.",
      content: "A 15-minute yoga routine to energize your body and mind. Includes sun salutations, stretches, and breathing exercises to set a positive tone for your day.",
      author: "Yoga Instructor",
    },
    {
      title: "Mindfulness in Daily Life",
      category: "article" as const,
      description: "Incorporate mindfulness into your everyday activities.",
      content: "Mindfulness is the practice of being present in the moment. You can practice mindfulness while eating, walking, or doing any daily activity. This can help reduce stress and improve overall well-being.",
      author: "Mental Health Expert",
    },
    {
      title: "Progressive Muscle Relaxation",
      category: "coping_strategy" as const,
      description: "Reduce physical tension through systematic relaxation.",
      content: "Tense each muscle group for 5 seconds, then release. Start from your toes and work up to your head. This technique helps identify and release physical tension caused by stress.",
      author: "Wellness Coach",
    },
    {
      title: "Crisis Text Line",
      category: "crisis_hotline" as const,
      description: "Text-based crisis support available 24/7.",
      content: "Text HOME to 741741 to connect with a trained crisis counselor. Available for any crisis, including mental health, substance abuse, or relationship issues.",
      link: "https://www.crisistextline.org",
      author: "Crisis Support",
    },
  ];

  try {
    await db.insert(resources).values(seedData);
    console.log("[Database] Resources seeded successfully");
  } catch (error) {
    console.error("[Database] Failed to seed resources:", error);
  }
}
