import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { saveChatMessage, getChatHistory, saveMoodEntry, getMoodHistory, getLatestMoodEntry, getAllResources, getResourcesByCategory, seedResources } from "./db";
import { invokeLLM } from "./_core/llm";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Chat procedures
  chat: router({
    // Send a message and get AI response
    sendMessage: protectedProcedure
      .input(z.object({
        message: z.string().min(1).max(5000),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          // Save user message
          await saveChatMessage(ctx.user.id, "user", input.message);

          // Get chat history for context
          const history = await getChatHistory(ctx.user.id, 10);

          // Prepare messages for LLM
          const systemMessage = `You are a compassionate and empathetic mental health support chatbot. Your role is to listen, understand, and provide supportive guidance. 
              
              Guidelines:
              - Be warm, non-judgmental, and supportive
              - Listen actively and validate feelings
              - Provide practical coping strategies when appropriate
              - Encourage professional help when needed
              - Never provide medical diagnoses
              - Keep responses concise and focused
              - Use encouraging language
              - If someone mentions crisis or self-harm, provide crisis resources`;
          
          const messages: any[] = [
            {
              role: "system",
              content: systemMessage,
            },
            ...history.map(msg => ({
              role: msg.role,
              content: msg.content,
            })),
            {
              role: "user",
              content: input.message,
            },
          ];

          // Get AI response
          const response = await invokeLLM({
            messages,
          });

          const content = response.choices[0]?.message?.content;
          const aiResponse = typeof content === 'string' ? content : "I appreciate you sharing. How are you feeling right now?";

          // Save AI response
          await saveChatMessage(ctx.user.id, "assistant", aiResponse);

          return {
            message: aiResponse,
          };
        } catch (error) {
          console.error("[Chat] Error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to process message",
          });
        }
      }),

    // Get chat history
    getHistory: protectedProcedure
      .input(z.object({
        limit: z.number().min(1).max(100).default(50),
      }).optional())
      .query(async ({ ctx, input }) => {
        const history = await getChatHistory(ctx.user.id, input?.limit || 50);
        return history;
      }),

    // Clear chat history
    clearHistory: protectedProcedure
      .mutation(async ({ ctx }) => {
        // In a real app, you'd delete from database
        // For now, just return success
        return { success: true };
      }),
  }),

  // Mood tracking procedures
  mood: router({
    // Log a mood entry
    logMood: protectedProcedure
      .input(z.object({
        moodLevel: z.number().min(1).max(5),
        moodLabel: z.string().min(1).max(50),
        notes: z.string().max(500).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        await saveMoodEntry(ctx.user.id, input.moodLevel, input.moodLabel, input.notes);
        return { success: true };
      }),

    // Get mood history
    getHistory: protectedProcedure
      .input(z.object({
        days: z.number().min(1).max(365).default(30),
      }).optional())
      .query(async ({ ctx, input }) => {
        const history = await getMoodHistory(ctx.user.id, input?.days || 30);
        return history;
      }),

    // Get latest mood entry
    getLatest: protectedProcedure
      .query(async ({ ctx }) => {
        const latest = await getLatestMoodEntry(ctx.user.id);
        return latest;
      }),

    // Get mood statistics
    getStats: protectedProcedure
      .input(z.object({
        days: z.number().min(1).max(365).default(30),
      }).optional())
      .query(async ({ ctx, input }) => {
        const history = await getMoodHistory(ctx.user.id, input?.days || 30);

        if (history.length === 0) {
          return {
            averageMood: 0,
            totalEntries: 0,
            moodDistribution: {},
          };
        }

        const averageMood = history.reduce((sum, entry) => sum + entry.moodLevel, 0) / history.length;
        const moodDistribution = history.reduce((acc, entry) => {
          acc[entry.moodLabel] = (acc[entry.moodLabel] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);

        return {
          averageMood: Math.round(averageMood * 10) / 10,
          totalEntries: history.length,
          moodDistribution,
        };
      }),
  }),

  // Resources procedures
  resources: router({
    // Get all resources
    getAll: publicProcedure
      .query(async () => {
        const allResources = await getAllResources();
        return allResources;
      }),

    // Get resources by category
    getByCategory: publicProcedure
      .input(z.object({
        category: z.enum(["article", "coping_strategy", "crisis_hotline", "meditation", "exercise"]),
      }))
      .query(async ({ input }) => {
        const categoryResources = await getResourcesByCategory(input.category);
        return categoryResources;
      }),

    // Seed resources (admin only)
    seed: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only admins can seed resources",
          });
        }
        await seedResources();
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
