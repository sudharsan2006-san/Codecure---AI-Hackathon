import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("Chat Procedures", () => {
  it("should get empty chat history for new user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const history = await caller.chat.getHistory({ limit: 50 });

    expect(Array.isArray(history)).toBe(true);
    expect(history.length).toBeGreaterThanOrEqual(0);
  });

  it("should send a message and receive AI response", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.sendMessage({
      message: "I'm feeling anxious today",
    });

    expect(result).toHaveProperty("message");
    expect(typeof result.message).toBe("string");
    expect(result.message.length).toBeGreaterThan(0);
  });

  it("should reject empty messages", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.chat.sendMessage({ message: "" });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });

  it("should reject messages exceeding max length", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const longMessage = "a".repeat(5001);

    try {
      await caller.chat.sendMessage({ message: longMessage });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });
});

describe("Mood Procedures", () => {
  it("should log a mood entry", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.mood.logMood({
      moodLevel: 4,
      moodLabel: "Calm",
      notes: "Had a good day",
    });

    expect(result).toEqual({ success: true });
  });

  it("should reject invalid mood levels", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.mood.logMood({
        moodLevel: 6, // Invalid: max is 5
        moodLabel: "Invalid",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });

  it("should get mood history", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // First log a mood
    await caller.mood.logMood({
      moodLevel: 3,
      moodLabel: "Neutral",
    });

    // Then get history
    const history = await caller.mood.getHistory({ days: 30 });

    expect(Array.isArray(history)).toBe(true);
  });

  it("should get mood statistics", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Log multiple moods
    await caller.mood.logMood({ moodLevel: 2, moodLabel: "Anxious" });
    await caller.mood.logMood({ moodLevel: 4, moodLabel: "Calm" });
    await caller.mood.logMood({ moodLevel: 5, moodLabel: "Happy" });

    const stats = await caller.mood.getStats({ days: 30 });

    expect(stats).toHaveProperty("averageMood");
    expect(stats).toHaveProperty("totalEntries");
    expect(stats).toHaveProperty("moodDistribution");
    expect(typeof stats.averageMood).toBe("number");
    expect(stats.totalEntries).toBeGreaterThanOrEqual(0);
  });

  it("should get latest mood entry", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Log a mood
    await caller.mood.logMood({
      moodLevel: 4,
      moodLabel: "Calm",
      notes: "Feeling peaceful",
    });

    const latest = await caller.mood.getLatest();

    expect(latest).toBeDefined();
    if (latest) {
      expect(latest.moodLevel).toBe(4);
      expect(latest.moodLabel).toBe("Calm");
    }
  });
});

describe("Resources Procedures", () => {
  it("should get all resources", async () => {
    const caller = appRouter.createCaller({} as any);

    const resources = await caller.resources.getAll();

    expect(Array.isArray(resources)).toBe(true);
  });

  it("should get resources by category", async () => {
    const caller = appRouter.createCaller({} as any);

    const articles = await caller.resources.getByCategory({
      category: "article",
    });

    expect(Array.isArray(articles)).toBe(true);
    articles.forEach((resource) => {
      expect(resource.category).toBe("article");
    });
  });

  it("should seed resources as admin", async () => {
    const adminUser: AuthenticatedUser = {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin User",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    const ctx: TrpcContext = {
      user: adminUser,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const caller = appRouter.createCaller(ctx);

    const result = await caller.resources.seed();

    expect(result).toEqual({ success: true });
  });

  it("should reject non-admin seed attempts", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.resources.seed();
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });
});

describe("Auth Procedures", () => {
  it("should get current user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const user = await caller.auth.me();

    expect(user).toBeDefined();
    expect(user?.id).toBe(1);
    expect(user?.name).toBe("Test User");
  });

  it("should logout user", async () => {
    const { ctx } = createAuthContext();
    const clearedCookies: any[] = [];

    ctx.res = {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as any;

    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();

    expect(result).toEqual({ success: true });
    expect(clearedCookies.length).toBeGreaterThan(0);
  });
});
