import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Brain, Info, AlertCircle, RefreshCcw, Smile, Meh, Frown, Sparkles, Settings, Sliders, BarChart2, MessageCircle, Activity, Droplets, Moon, Zap, Wind, MessageSquare, PenTool, ShieldCheck, Menu, X, Heart } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { geminiService } from './services/gemini';
import { cn } from './lib/utils';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

const MOODS = [
  { emoji: '😊', label: 'Happy', color: 'text-yellow-400' },
  { emoji: '😌', label: 'Calm', color: 'text-blue-400' },
  { emoji: '😰', label: 'Anxious', color: 'text-orange-400' },
  { emoji: '😢', label: 'Sad', color: 'text-blue-500' },
];

const QUICK_ACTIONS = [
  { label: "I'm feeling anxious 😰", value: "I'm feeling anxious" },
  { label: "Had a rough day 😔", value: "I had a rough day" },
  { label: "Need to talk 💬", value: "I just need someone to talk to" },
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showResources, setShowResources] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');
  const [temperature, setTemperature] = useState(0.7);
  const [isBreathing, setIsBreathing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const response = await fetch('/api/messages');
        if (response.ok) {
          const data = await response.json();
          setMessages(data.map((m: any) => ({
            ...m,
            timestamp: new Date(m.timestamp)
          })));
        }
      } catch (error) {
        console.error('Error fetching messages:', error);
      }
    };
    fetchMessages();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: textToSend,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    
    // Save user message to API
    try {
      fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: userMessage.id,
          role: userMessage.role,
          text: userMessage.text
        }),
      });
    } catch (e) { console.error('Failed to save user message', e); }

    if (!textOverride) setInput('');
    setIsLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.role,
        parts: [{ text: m.text }],
      }));

      let assistantText = '';
      const assistantMessageId = (Date.now() + 1).toString();
      
      setMessages((prev) => [
        ...prev,
        { id: assistantMessageId, role: 'model', text: '', timestamp: new Date() },
      ]);

      const stream = geminiService.sendMessageStream(textToSend, history, temperature);
      for await (const chunk of stream) {
        assistantText += chunk;
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantMessageId ? { ...m, text: assistantText } : m))
        );
      }

      // Save assistant message to API after stream completes
      try {
        fetch('/api/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: assistantMessageId,
            role: 'model',
            text: assistantText
          }),
        });
      } catch (e) { console.error('Failed to save assistant message', e); }
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: 'model',
          text: "I'm sorry, I'm having a bit of trouble connecting right now. Please try again in a moment. 💜",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feedback: feedbackText }),
      });

      if (!response.ok) throw new Error('Failed to send feedback');

      const data = await response.json();
      
      // Add a system message to the chat to confirm feedback
      const confirmationMessage: Message = {
        id: Date.now().toString(),
        role: 'model',
        text: data.message,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, confirmationMessage]);
      
      setShowFeedback(false);
      setFeedbackText('');
    } catch (error) {
      console.error('Error sending feedback:', error);
      alert('Failed to send feedback. Please try again later. 💜');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-bg-dark text-slate-900 overflow-hidden relative">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Heartbeat (EKG) Animation */}
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.15]">
          <svg
            viewBox="0 0 1000 200"
            className="w-full h-32 lg:h-64 text-blue-500"
            preserveAspectRatio="none"
          >
            <motion.path
              d="M0,100 L200,100 L220,80 L240,120 L260,100 L300,100 L320,40 L340,160 L360,100 L400,100 L420,80 L440,120 L460,100 L600,100 L620,80 L640,120 L660,100 L700,100 L720,40 L740,160 L760,100 L800,100 L820,80 L840,120 L860,100 L1000,100"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ 
                pathLength: [0, 1],
                opacity: [0, 1, 0],
                x: [0, -100]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <motion.path
              d="M0,100 L200,100 L220,80 L240,120 L260,100 L300,100 L320,40 L340,160 L360,100 L400,100 L420,80 L440,120 L460,100 L600,100 L620,80 L640,120 L660,100 L700,100 L720,40 L740,160 L760,100 L800,100 L820,80 L840,120 L860,100 L1000,100"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ 
                pathLength: [0, 1],
                opacity: [0, 1, 0],
                x: [100, 0]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear",
                delay: 2
              }}
            />
          </svg>
        </div>

        {/* Heart Function Animation (Pulsing Heart) */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <motion.div
            animate={{
              scale: [1, 1.15, 1.05, 1.25, 1],
              opacity: [0.05, 0.1, 0.08, 0.12, 0.05],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              times: [0, 0.1, 0.2, 0.3, 1],
              ease: "easeInOut"
            }}
            className="text-red-500"
          >
            <Heart className="w-48 h-48 lg:w-96 lg:h-96 fill-current" />
          </motion.div>
        </div>

        {/* Floating Health Icons */}
        <motion.div
          animate={{
            y: [0, -40, 0],
            opacity: [0.03, 0.08, 0.03],
            rotate: [0, 15, -15, 0]
          }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[15%] left-[10%] text-brand"
        >
          <Heart className="w-12 h-12" />
        </motion.div>

        <motion.div
          animate={{
            y: [0, 40, 0],
            opacity: [0.02, 0.06, 0.02],
            rotate: [0, -20, 20, 0]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-[20%] right-[10%] text-blue-800"
        >
          <Activity className="w-16 h-16" />
        </motion.div>
        
        <motion.div
          animate={{
            x: [0, 100, -50, 0],
            y: [0, 50, 100, 0],
            scale: [1, 1.2, 0.9, 1],
            opacity: [0.1, 0.2, 0.1, 0.1]
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -top-48 -left-48 w-[600px] h-[600px] bg-pink-200 rounded-full blur-[150px]"
        />
        <motion.div
          animate={{
            x: [0, -80, 120, 0],
            y: [0, 100, -50, 0],
            scale: [1, 1.1, 1.2, 1],
            opacity: [0.08, 0.15, 0.08, 0.08]
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/4 -right-48 w-[500px] h-[500px] bg-rose-100 rounded-full blur-[130px]"
        />
      </div>

      {/* Sidebar Overlay for Mobile */}
      <AnimatePresence>
        {showSidebar && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowSidebar(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-[70] w-72 bg-bg-sidebar border-r border-pink-100 flex flex-col p-6 overflow-y-auto scrollbar-hide transition-transform duration-300 lg:relative lg:translate-x-0",
        showSidebar ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center justify-between mb-10 lg:hidden">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-brand" />
            <span className="font-bold text-slate-900">MindCare</span>
          </div>
          <button 
            onClick={() => setShowSidebar(false)}
            className="p-2 hover:bg-pink-50 rounded-xl transition-colors"
          >
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        <div className="mb-10">
          <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-4">How are you feeling?</p>
          <div className="grid grid-cols-2 gap-3">
            {MOODS.map((m) => (
              <button
                key={m.label}
                onClick={() => handleSend(`I'm feeling ${m.label.toLowerCase()} ${m.emoji}`)}
                className="bg-bg-card hover:bg-pink-50 transition-colors p-4 rounded-2xl flex flex-col items-center gap-2 border border-pink-100"
              >
                <span className="text-2xl">{m.emoji}</span>
                <span className="text-xs font-medium text-slate-600">{m.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="mb-10">
          <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-4">Quick Tools</p>
          <button 
            onClick={() => setIsBreathing(!isBreathing)}
            className="w-full bg-bg-card hover:bg-pink-50 transition-colors p-3 rounded-2xl flex items-center gap-3 border border-pink-100 group"
          >
            <div className="w-10 h-10 rounded-xl bg-brand/10 flex items-center justify-center text-brand group-hover:scale-110 transition-transform">
              <Wind className="w-5 h-5" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-slate-900">Breathing</p>
              <p className="text-[10px] text-text-muted">Calm your mind</p>
            </div>
          </button>
        </div>

        <div className="mt-auto">
          <div className="bg-brand/5 border border-brand/10 p-4 rounded-2xl flex gap-3">
            <AlertCircle className="w-5 h-5 text-brand/50 shrink-0" />
            <p className="text-[10px] text-brand/40 leading-relaxed">
              This is not professional help. If in crisis, contact emergency services.
            </p>
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col relative">
        {/* Header */}
        <header className="h-16 lg:h-20 border-b border-pink-100 flex items-center justify-between px-4 lg:px-8 bg-white/50 backdrop-blur-xl z-10">
          <div className="flex items-center gap-2 lg:gap-4">
            <button 
              onClick={() => setShowSidebar(true)}
              className="p-1.5 hover:bg-pink-50 rounded-xl transition-colors lg:hidden"
            >
              <Menu className="w-5 h-5 text-slate-600" />
            </button>
            <div className="w-8 h-8 lg:w-10 lg:h-10 rounded-xl bg-brand flex items-center justify-center shadow-lg shadow-brand/20">
              <Brain className="w-4 h-4 lg:w-6 lg:h-6 text-white" />
            </div>
            <div>
              <h1 className="text-base lg:text-xl font-bold tracking-tight text-slate-900">MindCare</h1>
              <p className="text-[8px] lg:text-xs text-brand font-medium">Welcome, Guest 💜</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 lg:gap-3">
            <button 
              onClick={() => setShowFeedback(true)}
              className="bg-white hover:bg-pink-50 transition-colors px-2 lg:px-4 py-1.5 lg:py-2 rounded-lg lg:rounded-xl text-[9px] lg:text-xs font-semibold flex items-center gap-1.5 border border-pink-100 text-slate-600 shadow-sm"
            >
              <PenTool className="w-3 h-3 lg:w-4 lg:h-4" />
              <span className="hidden sm:inline">Feedback</span>
            </button>
            <button 
              onClick={() => setShowResources(true)}
              className="bg-brand/10 hover:bg-brand/20 text-brand transition-colors px-2 lg:px-4 py-1.5 lg:py-2 rounded-lg lg:rounded-xl text-[9px] lg:text-xs font-bold flex items-center gap-1.5 border border-brand/20 shadow-sm"
            >
              <span className="bg-brand text-white px-1 py-0.5 rounded text-[7px] lg:text-[10px]">SOS</span>
              Help
            </button>
          </div>
        </header>

        {/* Chat Content */}
        <div className="flex-1 overflow-y-auto p-3 lg:p-8 scrollbar-hide">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-lg mx-auto px-4 py-6">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-16 h-16 lg:w-24 lg:h-24 rounded-2xl lg:rounded-3xl bg-brand/20 flex items-center justify-center mb-4 lg:mb-8 border border-brand/20"
              >
                <Brain className="w-8 h-8 lg:w-12 lg:h-12 text-brand" />
              </motion.div>
              <motion.h2 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="text-xl lg:text-4xl font-bold mb-2 lg:mb-4"
              >
                Hello! I'm here for you 💜
              </motion.h2>
              <motion.p 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-xs lg:text-base text-slate-500 mb-6 lg:mb-10"
              >
                This is a safe space. How are you feeling today?
              </motion.p>
              
              <div className="flex flex-wrap justify-center gap-2 lg:gap-3">
                {QUICK_ACTIONS.map((action, idx) => (
                  <motion.button
                    key={action.label}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.3 + idx * 0.1 }}
                    onClick={() => handleSend(action.value)}
                    className="bg-white hover:bg-pink-50 border border-pink-100 px-4 lg:px-6 py-2.5 lg:py-3 rounded-full text-xs lg:text-sm font-medium transition-all hover:scale-105 text-slate-600 shadow-sm"
                  >
                    {action.label}
                  </motion.button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-6 lg:space-y-8">
              {messages.map((m) => (
                <motion.div
                  key={m.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex flex-col",
                    m.role === 'user' ? "items-end" : "items-start"
                  )}
                >
                  <div className={cn(
                    "max-w-[90%] lg:max-w-[80%] p-4 lg:p-5 rounded-2xl lg:rounded-3xl text-xs lg:text-sm leading-relaxed",
                    m.role === 'user' 
                      ? "bg-brand text-white rounded-tr-none shadow-lg shadow-brand/10" 
                      : "bg-white text-slate-800 rounded-tl-none border border-pink-100 shadow-sm"
                  )}>
                    <div className="markdown-body">
                      <ReactMarkdown>{m.text}</ReactMarkdown>
                    </div>
                  </div>
                  <span className="text-[9px] lg:text-[10px] text-text-muted mt-2 px-2 uppercase tracking-widest font-bold">
                    {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </motion.div>
              ))}
              {isLoading && messages[messages.length - 1].role === 'user' && (
                <div className="flex items-center gap-3 text-brand text-[10px] lg:text-xs font-bold animate-pulse">
                  <div className="w-1.5 h-1.5 lg:w-2 lg:h-2 rounded-full bg-brand" />
                  <span>MindCare is typing...</span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="p-3 lg:p-8 pt-0">
          <div className="max-w-3xl mx-auto relative">
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSend(); }}
              className="relative flex items-center"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Share your thoughts... 💜"
                className="w-full bg-white border border-pink-100 rounded-xl lg:rounded-2xl p-3.5 lg:p-5 pr-12 lg:pr-16 text-xs lg:text-sm focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all placeholder:text-slate-400 text-slate-900 shadow-sm"
                disabled={isLoading}
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className={cn(
                  "absolute right-1.5 lg:right-3 p-2 lg:p-3 rounded-lg lg:rounded-xl transition-all",
                  input.trim() ? "bg-brand text-white shadow-lg shadow-brand/20 scale-100" : "bg-slate-100 text-slate-300 scale-90"
                )}
              >
                <Send className="w-3.5 h-3.5 lg:w-5 lg:h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Breathing Overlay */}
        <AnimatePresence>
          {isBreathing && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 bg-bg-dark/95 backdrop-blur-xl flex flex-col items-center justify-center p-8 text-center"
            >
              <button 
                onClick={() => setIsBreathing(false)}
                className="absolute top-8 right-8 p-3 rounded-full bg-white hover:bg-pink-50 transition-colors shadow-sm border border-pink-100"
              >
                <RefreshCcw className="w-6 h-6 text-slate-600" />
              </button>
              
              <motion.div
                animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                className="w-32 h-32 lg:w-48 lg:h-48 rounded-[2rem] lg:rounded-[3rem] bg-brand/20 flex items-center justify-center mb-8 lg:mb-12 relative border border-brand/30"
              >
                <div className="absolute inset-0 rounded-[2rem] lg:rounded-[3rem] border-4 border-brand/30 animate-pulse" />
                <Brain className="w-12 h-12 lg:w-20 lg:h-20 text-brand" />
              </motion.div>
              
              <h2 className="text-2xl lg:text-3xl font-bold mb-3 lg:mb-4 text-slate-900">Breathe In...</h2>
              <p className="text-xs lg:text-base text-slate-500 max-w-xs">Follow the circle. Let your worries drift away with each breath.</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* SOS Modal */}
        <AnimatePresence>
          {showResources && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={() => setShowResources(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-bg-card border border-white/10 p-6 lg:p-8 rounded-[1.5rem] lg:rounded-[2rem] max-w-md w-full shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-3 lg:gap-4 mb-5 lg:mb-6">
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl lg:rounded-2xl bg-brand flex items-center justify-center text-white shadow-lg shadow-brand/20">
                    <AlertCircle className="w-6 h-6 lg:w-7 lg:h-7" />
                  </div>
                  <div>
                    <h3 className="text-xl lg:text-2xl font-bold text-slate-900">Emergency Help</h3>
                    <p className="text-[10px] lg:text-xs text-brand font-bold uppercase tracking-widest">You are not alone</p>
                  </div>
                </div>
                
                <div className="space-y-3 lg:space-y-4">
                  <a href="tel:988" className="flex items-center justify-between p-4 lg:p-5 bg-white rounded-xl lg:rounded-2xl border border-pink-100 hover:bg-pink-50 transition-colors group shadow-sm">
                    <div>
                      <p className="text-xs lg:text-sm font-bold text-slate-900">Suicide & Crisis Lifeline</p>
                      <p className="text-[10px] lg:text-xs text-slate-500">Available 24/7 in the US</p>
                    </div>
                    <span className="text-brand font-mono font-bold text-lg lg:text-xl group-hover:scale-110 transition-transform">988</span>
                  </a>
                  <a href="https://www.crisistextline.org/" target="_blank" className="flex items-center justify-between p-4 lg:p-5 bg-white rounded-xl lg:rounded-2xl border border-pink-100 hover:bg-pink-50 transition-colors group shadow-sm">
                    <div>
                      <p className="text-xs lg:text-sm font-bold text-slate-900">Crisis Text Line</p>
                      <p className="text-[10px] lg:text-xs text-slate-500">Text HOME to 741741</p>
                    </div>
                    <MessageSquare className="w-5 h-5 lg:w-6 lg:h-6 text-brand" />
                  </a>
                </div>
                
                <button 
                  onClick={() => setShowResources(false)}
                  className="w-full mt-6 lg:mt-8 py-3.5 lg:py-4 bg-white hover:bg-pink-50 border border-pink-100 rounded-xl lg:rounded-2xl text-xs lg:text-sm font-bold transition-colors text-slate-600 shadow-sm"
                >
                  Close
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Feedback Modal */}
        <AnimatePresence>
          {showFeedback && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
              onClick={() => setShowFeedback(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-bg-card border border-white/10 p-6 lg:p-8 rounded-[1.5rem] lg:rounded-[2rem] max-w-md w-full shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-3 lg:gap-4 mb-5 lg:mb-6">
                  <div className="w-10 h-10 lg:w-12 lg:h-12 rounded-xl lg:rounded-2xl bg-brand flex items-center justify-center text-white shadow-lg shadow-brand/20">
                    <PenTool className="w-6 h-6 lg:w-7 lg:h-7" />
                  </div>
                  <div>
                    <h3 className="text-xl lg:text-2xl font-bold text-slate-900">Feedback</h3>
                    <p className="text-[10px] lg:text-xs text-brand font-bold uppercase tracking-widest">We'd love to hear from you</p>
                  </div>
                </div>
                
                <form onSubmit={handleFeedbackSubmit} className="space-y-3 lg:space-y-4">
                  <textarea
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="Tell us what you think..."
                    className="w-full h-28 lg:h-32 bg-white border border-pink-100 rounded-xl lg:rounded-2xl p-3 lg:p-4 text-xs lg:text-sm focus:outline-none focus:ring-2 focus:ring-brand/30 transition-all placeholder:text-slate-400 text-slate-900 shadow-sm resize-none"
                    required
                  />
                  <div className="flex gap-2 lg:gap-3">
                    <button 
                      type="button"
                      onClick={() => setShowFeedback(false)}
                      className="flex-1 py-3 lg:py-4 bg-white hover:bg-pink-50 border border-pink-100 rounded-xl lg:rounded-2xl text-xs lg:text-sm font-bold transition-colors text-slate-600 shadow-sm"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-3 lg:py-4 bg-brand hover:bg-brand/90 rounded-xl lg:rounded-2xl text-xs lg:text-sm font-bold transition-all shadow-lg shadow-brand/20 text-white"
                    >
                      Send Email
                    </button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
