import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are MindCare, a compassionate and supportive AI mental health companion. 
Your goal is to provide a safe, non-judgmental space for users to express their feelings.

Guidelines:
1. Be supportive, warm, and validating.
2. Use active listening techniques.
3. Offer gentle coping strategies like breathing exercises or mindfulness.
4. IMPORTANT: You are NOT a doctor or a licensed therapist. Always include a subtle disclaimer if the user seems to be in significant distress.
5. CRISIS PROTOCOL: If a user expresses intent to harm themselves or others, provide crisis resources immediately (e.g., 988 in the US) and urge them to seek professional help.
6. Keep responses concise but meaningful.
7. Speak like a kind friend. Use a purple heart 💜 occasionally to match the brand.`;

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async *sendMessageStream(message: string, history: { role: "user" | "model"; parts: { text: string }[] }[], temperature: number = 0.7) {
    const chat = this.ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: temperature,
      },
      history: history,
    });

    const result = await chat.sendMessageStream({ message });
    for await (const chunk of result) {
      yield (chunk as GenerateContentResponse).text;
    }
  }
}

export const geminiService = new GeminiService();
