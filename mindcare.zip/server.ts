import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Database
const db = new Database("mindcare.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    role TEXT,
    text TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/messages", (req, res) => {
    const messages = db.prepare("SELECT * FROM messages ORDER BY timestamp ASC").all();
    res.json(messages.map(m => ({
      ...m,
      timestamp: new Date(m.timestamp)
    })));
  });

  app.post("/api/messages", (req, res) => {
    const { id, role, text } = req.body;
    if (!id || !role || !text) {
      return res.status(400).json({ error: "Missing fields" });
    }
    db.prepare("INSERT INTO messages (id, role, text) VALUES (?, ?, ?)").run(id, role, text);
    res.json({ success: true });
  });

  app.post("/api/feedback", (req, res) => {
    const { feedback } = req.body;
    
    if (!feedback) {
      return res.status(400).json({ error: "Feedback is required" });
    }

    console.log("--- NEW FEEDBACK RECEIVED ---");
    console.log("To: sudharsan9001@gmail.com");
    console.log("Content:", feedback);
    console.log("-----------------------------");

    res.json({ message: "Feedback received successfully! Thank you. 💜" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
