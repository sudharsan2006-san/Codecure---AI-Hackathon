import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Heart, Info, AlertCircle, RefreshCcw, Smile, Meh, Frown, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { geminiService } from './services/gemini';
import { cn } from './lib/utils';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

const MOODS = [
  { icon: Smile, label: 'Great', color: 'text-emerald-500', bg: 'bg-emerald-50' },
  { icon: Meh, label: 'Okay', color: 'text-amber-500', bg: 'bg-amber-50' },
  { icon: Frown, label: 'Struggling', color: 'text-rose-500', bg: 'bg-rose-50' },
];

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'model',
      text: "Hello, I'm SereneMind. I'm here to listen and support you. How are you feeling today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showResources, setShowResources] = useState(false);
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const history = messages.map((m) => ({
        role: m.role,
        parts: [{ text: m.text }],
      }));

      let assistantText = '';
      const assistantMessageId = (Date.now() + 1).toString();
      
      setMessages((prev) => [
        ...prev,
        { id: assistantMessageId, role: 'model', text: '', timestamp: new Date() },
      ]);

      const stream = geminiService.sendMessageStream(input, history);
      for await (const chunk of stream) {
        assistantText += chunk;
        setMessages((prev) =>
          prev.map((m) => (m.id === assistantMessageId ? { ...m, text: assistantText } : m))
        );
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: 'model',
          text: "I'm sorry, I'm having a bit of trouble connecting right now. Please try again in a moment.",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMoodSelect = (mood: string) => {
    setSelectedMood(mood);
    const moodText = `I'm feeling ${mood.toLowerCase()} today.`;
    setInput(moodText);
    // Auto-send if it's the first interaction or just a quick check-in
    if (messages.length === 1) {
      setTimeout(() => handleSend(), 100);
    }
  };

  return (
    <div className="min-h-screen flex flex-col max-w-2xl mx-auto bg-cream shadow-2xl border-x border-stone-200">
      {/* Header */}
      <header className="p-6 border-b border-stone-200 bg-white/80 backdrop-blur-md sticky top-0 z-10 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-sage flex items-center justify-center text-white shadow-inner">
            <Heart className="w-6 h-6 fill-current" />
          </div>
          <div>
            <h1 className="font-serif text-2xl font-semibold text-stone-800 leading-tight">SereneMind</h1>
            <p className="text-xs text-stone-500 uppercase tracking-widest font-medium">Your AI Companion</p>
          </div>
        </div>
        <button 
          onClick={() => setShowResources(!showResources)}
          className="p-2 rounded-full hover:bg-stone-100 transition-colors text-stone-400 hover:text-rose-500"
          title="Crisis Resources"
        >
          <AlertCircle className="w-6 h-6" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-hide">
        {/* Mood Check-in (only show at start or when requested) */}
        {messages.length < 3 && !selectedMood && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-stone-100 space-y-4"
          >
            <h2 className="font-serif text-lg text-center text-stone-700">How are you feeling right now?</h2>
            <div className="flex justify-center gap-4">
              {MOODS.map((m) => (
                <button
                  key={m.label}
                  onClick={() => handleMoodSelect(m.label)}
                  className={cn(
                    "flex flex-col items-center gap-2 p-4 rounded-2xl transition-all hover:scale-105",
                    m.bg,
                    m.color
                  )}
                >
                  <m.icon className="w-8 h-8" />
                  <span className="text-xs font-semibold uppercase tracking-wider">{m.label}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Crisis Resources Panel */}
        <AnimatePresence>
          {showResources && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-rose-50 border border-rose-100 p-4 rounded-2xl space-y-3 mb-4">
                <div className="flex items-center gap-2 text-rose-700 font-semibold">
                  <AlertCircle className="w-5 h-5" />
                  <h3>Crisis Resources</h3>
                </div>
                <p className="text-sm text-rose-600">If you are in immediate danger, please contact emergency services or a crisis hotline.</p>
                <div className="grid grid-cols-1 gap-2 text-sm">
                  <a href="tel:988" className="flex justify-between p-2 bg-white rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors">
                    <span>988 Suicide & Crisis Lifeline (USA)</span>
                    <span className="font-mono font-bold">988</span>
                  </a>
                  <a href="https://www.crisistextline.org/" target="_blank" className="flex justify-between p-2 bg-white rounded-lg border border-rose-200 hover:bg-rose-100 transition-colors">
                    <span>Crisis Text Line</span>
                    <span className="font-mono font-bold">Text HOME to 741741</span>
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Messages */}
        <div className="space-y-4">
          {messages.map((m, idx) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, x: m.role === 'user' ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={cn(
                "flex flex-col max-w-[85%]",
                m.role === 'user' ? "ml-auto items-end" : "mr-auto items-start"
              )}
            >
              <div
                className={cn(
                  "p-4 rounded-3xl text-sm shadow-sm",
                  m.role === 'user'
                    ? "bg-sage text-white rounded-tr-none"
                    : "bg-white text-stone-800 border border-stone-100 rounded-tl-none"
                )}
              >
                <div className="markdown-body">
                  <ReactMarkdown>{m.text}</ReactMarkdown>
                </div>
              </div>
              <span className="text-[10px] text-stone-400 mt-1 px-2">
                {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </motion.div>
          ))}
          {isLoading && messages[messages.length - 1].role === 'user' && (
            <div className="flex items-center gap-2 text-stone-400 text-xs animate-pulse ml-2">
              <Sparkles className="w-3 h-3" />
              <span>SereneMind is thinking...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Footer / Input */}
      <footer className="p-4 bg-white border-t border-stone-200">
        <form onSubmit={handleSend} className="relative flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Share what's on your mind..."
            className="w-full p-4 pr-14 bg-stone-50 border border-stone-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-sage/20 focus:border-sage transition-all"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className={cn(
              "absolute right-2 p-2 rounded-full transition-all",
              input.trim() ? "bg-sage text-white shadow-lg scale-100" : "bg-stone-200 text-stone-400 scale-90"
            )}
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
        <p className="text-[10px] text-center text-stone-400 mt-3 uppercase tracking-widest font-medium">
          SereneMind is an AI companion, not a medical professional.
        </p>
      </footer>
    </div>
  );
}
